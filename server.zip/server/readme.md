## To run the app

1 - go to /server

2 - npm i

3 - node app.js or nodemon app.js

in the browser open => localhost:3001
